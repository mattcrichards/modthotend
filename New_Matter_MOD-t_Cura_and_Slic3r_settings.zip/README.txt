                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1535333
New Matter MOD-t Cura and Slic3r settings by energywave is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Here I share the profiles I'm using to successfully print objects with my New Matter MOD-t firmware ver. 0.15.0, using:
- Cura ver. 15.x (tested with 15.04.3, 15.04.5 and 15.04.6)
- Cura ver. 2.x (tested with 2.5 and 2.6)
- Cura ver. 3.x (tested with 3.03 and 3.1)
- Cura ver. 3.6+ (tested with 4.0 beta)
- Slic3r ver. 1.2.9.

To be noted that with latest firmwares I where not able to complete other than a very small object (frequently not that either...) sliced with Slic3r due to a **bug in MOD-t firmware** that evaluate wrongly slic3r gcode, generating blobs of extrusion here and there that will make the bed hop on pinion rods.
So slic3r is not encouraged as the firmware will never be improved again... (sigh!)

I'll update these profiles as I experiment and find better values, so here is the reference of last time I've updated them:
* Cura 15.04.x settings: **06 February 2017**
* Cura 2.x settings: **07 June 2017**
* Cura 3.6+ settings: **19 february 2019**
* Slic3r settings: **18 October 2016**

If you have improvements, corrections, concerns, whatever you want please write me in comments :)

**DISCLAIMER: you'll take all te risk of using these profiles, They are not official as I'm not in any way linked to New Matter. I take no liabilities if something bad happens to your 3D printer, you and only YOU are the responsible of the correct operation of your printer.**

# Cura 15.04.x settings

## Install MOD-t in Cura 15.04.x

1. Install latest version of Cura on the branch 15.04 from [Ultimaker site](https://ultimaker.com/en/products/cura-software).
2. Open Cura. The "add new machine widard" opens (or, if you didn't just installed Cura, just go to **Machine** -> **Add new machine...** to open the same dialog). Press **Next**, select **other** and press **Next**, select **Custom**, press **Next** and insert these data:
Machine name: **MOD-t**
Machine width X (mm): **155.4**
Machine depth Y (mm): **104.6**
Machine height Z (mm): **130**
Nozzle size (mm): **0.4**
Heated bed: **NO**
Bed center is 0,0,0 (RoStock): **YES**
Then press **Finish**
4. Now click on the **File** -> **Open profile...** menu and select the `Cura_Profile_Backup_4.ini` to load a base working profile, ready to be customized based on your needs.
5. Click on **Start/End-GCode** tab and verify that GCode present is the same as the files `start_gcode.txt` for **start.code** and `end_gcode.txt` for **end.code**. If not overwrite it with the content of those file with copy/paste.

Ok, you're ready to load the stl file, slice it experimenting different parameters and print it!

## CHANGELOG

**06 February 2017**
* Updated retraction speed to the **real** maximum speed MOD-t can achieve: 6 mm/s (all greater values was capped at 6 mm/s)
* Returned to 2mm of retraction. In the previous profile that was 4, trying to address a severe oozing I was facing with some objects.
* Skirt enabled by default. I use them all the time as it can help a little bit to have a steady initial extrusion.

**30 June 2016**
* Updated start / end gcode to latest official provided. Adapted start gcode to not overlap to my Bed Clips (so it's greatly adviced to use this profile when using clips!)
* Implemented z-hop as per New Matter engineers advice to reduce bed slipping probability
* Removed skirt

**05 May 2016**
* Added start/end gcode that was not loading correctly from profile
* Profile was not loading correctly

**04 May 2016**
* Initial release

# Slic3r settings

## Install MOD-t in Slic3r 1.2.9

1. Download Slic3r from the [Slic3r website](http://slic3r.org/download)
2. Extract the zip content in a folder, let's assume c:\Slic3r
3. Create a link to c:\Slic3r\Slic3r.exe on the Desktop and Start Menu for easy open in the future (as Slic3r has not to be installed)
4. Open it!
5. Click in the upper menu on **File** -> **Load config bundle...** and open the `Slic3r_config_bundle 6.ini` file (that you have already downloaded to your PC from Thing files)

Here we go! You're ready to use MOD-t with Slic3r!


## Slic3r settings

Slic3r settings are divided in three groups:
* **Print settings** to control how to print (use the printer MOD-t)
* **Filament settings** to customize temperature, filament diameter and cooling options
* **Printer settings** to control 3d printer peculiarities.

There is no need to say you'll change every time Print settings to adapt to the desired settings in wich you want to print a specific model.
For that reason I've created several profiles with most useful (for me) print settings combination.
The profiles have this convention: **[layer height]-[quality]-[perimeter thickness]-[supports]**
Where every of those fields can assume these values:
* **layer height**: **100µm**, **200µm** or **300µm**
* **quality**: **HQ** (high quality) or **LQ** (low quality). The first will print slowly, the second faster.
* **perimeter thickness**: **MIN** (small perimeters for not resistant objects), **2mm** (for medium resistant objects) and **FILL** (for extra strong, 100% filled objects)
* **supports**: **sup** (generates supports) or **no sup** (don't generate supports)

## CHANGELOG

**18 October 2016**
* Specified 0.4mm as extrusion width instead of 0 (automatic) as often top solid infill has space between extrusion lines, like it was underextruding. With this settings I like more the surfaces.
* Increased first layer, small perimeters and small gap speed from 7 to 15 as they was really slow... No noticeable differences using the new speed but could vastly improve speed
* Changed first layer from 150% to 0.3mm so that if you change the layer height you'll not have to change the first layer due to a wrong 150% of what you insert
* Changed infill every layer 2 to 1 as that will improve the infill quality

**30 June 2016**
* Updated start / end gcode to latest official provided. Adapted start gcode to not overlap to my Bed Clips (so it's greatly adviced to use this profile when using clips!)
* Implemented z-hop as per New Matter engineers advice to reduce bed slipping probability
* Reduced xy_size_compensation to -0.1 as firmware 0.13 and newer are more precise.

**05 May 2016**
* Corrected xy_size_compensation, it was -0.3 for HQ and -0.4 for LQ but this is the clearance added to both sides so it was divided by two and is now equal to -0.15 for both LQ and HQ.

**04 May 2016**
* Initial release

# Cura 2.x, 3.x settings

## Install MOD-t in Cura 2.x or 3.x (PC)

1. Install Cura 2.x or 3.x from [Ultimaker site](https://ultimaker.com/en/products/cura-software)
2. Copy the provided **modt.def.json** file in the `Program files\Cura 2.x\resources\definitions` folder and the **modt_platform.stl** file into `Program Files\Cura 2.x\resources\meshes`
3. Open Cura. The Add new printer wizard shows. Select **MODt** printer in the **Other** section.
4. Take some time to select what parameters are important to you and to show in Settings -> Configure setting visibility
5. Please ensure that the following parameters on the right panels are as follow:
SHELL
  - Top/Bottom Thickness: a multiple of the Layer Height
  - Horizontal Expansion: -0.2
MATERIAL
  - Printing Temperature: 210
  - Flow: 95% (it really depends on your filament type and material. My BQ filaments are better printed with 95 or even 90% flow, even if they are 1.75 diameter)
  - Retraction speed: 6
  - Retraction Minimum Travel: 10
  - Maximum Retraction Count: 10
  - Minimum Extrusion Distance Window: 2
SPEED
  - Travel speed: 60 (you can set 80 but absolutely not the proposed 120!!! I prefer 60 to reduce the probability that bed will hop on pinion rods... Very bad...)
TRAVEL
  - Z Hop When Retracted: yes
  - Z Hop Height: 2
BUILD PLATE ADHESION
  - Build Plate Adhesion Type: Skirt
  - Skirt Line Count: 1
  - Skirt/Brim Minimum Length: 100

Other than that remember to select the appropriate settings for every print like support, speed, thicknesses, etc.
I'll make some profiles to use like I did for Slic3r.

## Install MOD-t in Cura 2.x or 3.x (Mac)

The user **hsus** (thank you!) wrote some hints in the comments on how to make that work on the Mac. Here are his exact words for everyone's reference:
Right click the application, show contents, go into the Resources folder, in there is another resources folder which contains the meshes and definitions folders. Place modt.def.json in "definitions" and modt_platform.stl in "meshes".
After doing this the app won't run due to security reasons. Open up terminal and execute sudo xattr -cr '/Applications/Ultimaker Cura.app' and go through the rest of the steps as provided.

## CHANGELOG

**07 June 2017**
* Initial release

# Cura 3.6, 4.0 beta settings

## Install MOD-t in Cura 3.6, 4.0 beta (PC)

First a "thank you" to the user martinjuhasz that managed to create the machine definition for Cura 3.6. I've started from his definition to create the extrusor and changing all the settings.
1. Install Cura 3.6 or 4.0 beta (I encourage the last one) from [Ultimaker site](https://ultimaker.com/en/products/cura-software) All the instructions that follows refers to Cura 4.0 beta.
2. Download and extract somewhere the file **Cura 3.6+ settings.zip** from the files section. All the following lines refers to files you extracted from that zip file!
3. Copy the provided **modt.def.json** file (see point 2) in the `Program Files\Ultimaker Cura 4.0\resources\definitions` folder,
4. Copy the **modt_platform.stl** file (see point 2) into `Program Files\Ultimaker Cura 4.0\resources\meshes`
5. Copy the **modt_extruder_0.def.json** file (see point 2) into `Program Files\Ultimaker Cura 4.0\resources\extruders`
6. Open Cura. The Add new printer wizard shows. Select **New Matter MOD-t** printer in the **Other** section.
7. Take some time to select what parameters are important to you and to show in Settings -> Configure setting visibility
8. Import as a starting point the profile that I'm currently using, then you can customize what you want but you're starting from something working. Go in the upper right corner, into the toolbar section where you select the quality. A panel opens below. Click on the bottom right "Custom >" button. Now open the "profile" combobox, click on "Manage profile" menu item. You're now in the preference, Profiles section. Press the "Import" button and select the **200 micron LQ.curaprofile** file (see point 2). Now close the preferences window and, in the profile combobox, you'll have a 200 micron LQ: select it.

Remember to select the appropriate settings for every print like support, speed, thicknesses, etc.
I hope to have some time to create a set of profiles like I did with Slic3r but don't count on them soon...

## CHANGELOG

**19 February 2019**
* Initial release